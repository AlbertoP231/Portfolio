# HolaJuniors--A
Este es un reto de holajuniors.com es el reto 1_A del canal de Youtube  "iosonomauri"

![Reto1](https://user-images.githubusercontent.com/67514128/200358679-e1e1b047-328e-4821-bea7-15d8474dbcc0.png)
