# Desktop view




![Mycell_readme1](https://user-images.githubusercontent.com/67514128/200357361-a873f8c9-9cd7-43ef-a4b6-a4eccaecb612.jpg)






# Mobile view


![MyCell_movile](https://user-images.githubusercontent.com/67514128/200357232-0a6c715c-3e22-4f2f-8ff8-cdb9b24f8b28.jpg)










## For install proyect

1. download 
2. zip extrarct files 
3. Execute index.js on terminal (node.js ("index.js"))
